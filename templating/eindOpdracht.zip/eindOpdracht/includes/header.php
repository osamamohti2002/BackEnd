<!-- jouw HTML voor een Header komt hier... 
Gebruik hier tenminste een header afbeelding en een menu
Zorg dat je in het menu bij elk item een url parameter zet
om te bepalen welke inhoud er ingeladen moet worden in je html
-->

<header>
    <nav class="nav-bar">
        <a href="index.php?page=home">Home</a>
        <a href="index.php?page=onderwerp1">Onderwerp 1</a>
        <a href="index.php?page=onderwerp2">Onderwerp 2</a>
        <a href="index.php?page=onderwerp3">Onderwerp 3</a>
    </nav>
</header>